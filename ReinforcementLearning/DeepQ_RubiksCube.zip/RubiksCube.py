import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

#******* The following classes will define the Rubiks Cube ********#
class Side:

    # Initialize, it's just a 3X3 matrix, of all one value (which color it's set to be)
    def __init__(self,color):
        self.color = color
        self.values = np.full((3,3),color)

    # Getters for color and values
    def get_color(self): return self.color
    def get_values(self): return self.values

    # Function to return the percentage of values are it's set color
    def colors_correct(self):
        return np.sum(self.values == self.color)/self.values.size

    # Function for replacing values of a row
    def replace_row(self,row,values):
        self.values[row,:] = values

    # Function for replacing values of a col
    def replace_col(self,col,values):
        self.values[:,col] = values

class Cube:

    # Initialize, has 6 sides, with Face being the primary
    def __init__(self):

        # Create all sides, with colors 0,1,2,3,4,5
        self.face = Side(0)
        self.back = Side(1)
        self.right = Side(2)
        self.left = Side(3)
        self.top = Side(4)
        self.bottom = Side(5)

        # List of all rotation function calls
        self.rotations = np.array([self.rotate_top_row_right,self.rotate_mid_row_right,self.rotate_bottom_row_right,
                                   self.rotate_top_row_left,self.rotate_mid_row_left,self.rotate_bottom_row_left,
                                   self.rotate_left_col_up,self.rotate_mid_col_up,self.rotate_right_col_up,
                                   self.rotate_left_col_down,self.rotate_mid_col_down,self.rotate_right_col_down])

    # Getters for all the faces
    def get_face(self): return self.face
    def get_back(self): return self.back
    def get_right(self): return self.right
    def get_left(self): return self.left
    def get_top(self): return self.top
    def get_bottom(self): return self.bottom

    # Return the entire cube
    def get_cube(self):
        return np.array([self.face.values,self.back.values,self.right.values,
                         self.left.values,self.top.values,self.bottom.values])


    # Function for checking if solved
    def is_solved(self):

        # Assume true..
        solved = True

        # Then check each side
        if solved:
            solved = solved and np.all(self.face.get_values() == self.face.get_color())
        if solved:
            solved = solved and np.all(self.back.get_values() == self.back.get_color())
        if solved:
            solved = solved and np.all(self.right.get_values() == self.right.get_color())
        if solved:
            solved = solved and np.all(self.left.get_values() == self.left.get_color())
        if solved:
            solved = solved and np.all(self.top.get_values() == self.top.get_color())
        if solved:
            solved = solved and np.all(self.bottom.get_values() == self.bottom.get_color())

        # Return verdict
        return solved

    # Okay, let's shuffle the cube
    def shuffle(self,shuffles=100):
        for i in range(shuffles):
            rdex = np.random.randint(12)
            self.rotations[rdex]()

    # Printing the cube
    def print_cube(self):

        # Just print every Side
        print('Face')
        print(self.face.get_values())
        print('Back')
        print(self.back.get_values())
        print('Right')
        print(self.right.get_values())
        print('Left')
        print(self.left.get_values())
        print('Top')
        print(self.top.get_values())
        print('Bottom')
        print(self.bottom.get_values())

    # Get total reward for all sides (amount correct)
    def total_correct(self):

        return self.face.colors_correct() + self.back.colors_correct() + self.right.colors_correct() \
               + self.left.colors_correct() + self.top.colors_correct() + self.bottom.colors_correct()

    # Functions for performing 1 step rotations (with respect to the face)
    # Yes, it's redundant and error prone, don't care right now.
    # Didn't feel like making lists of order and abstracting into master function
    # This goes on for awhile!
    def rotate_top_row_right(self):

        # Get current side and next with respect to rotation
        curr = self.get_face()
        nxt = self.get_right()

        # Get values for each
        curr_values = curr.get_values()[0,:].copy()
        nxt_values = nxt.get_values()[0,:].copy()

        # Replace with values for current
        nxt.replace_row(0,curr_values)

        # Switch and repeat more times
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_back()
        nxt_values = nxt.get_values()[0,:].copy()
        nxt.replace_row(0,curr_values)

        curr = nxt
        curr_values = nxt_values
        nxt = self.get_left()
        nxt_values = nxt.get_values()[0,:].copy()
        nxt.replace_row(0,curr_values)

        # Don't need next values
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_face()
        nxt.replace_row(0,curr_values)

    def rotate_mid_row_right(self):

        # Get current side and next with respect to rotation
        curr = self.get_face()
        nxt = self.get_right()

        # Get values for each
        curr_values = curr.get_values()[1,:].copy()
        nxt_values = nxt.get_values()[1,:].copy()

        # Replace with values for current
        nxt.replace_row(1,curr_values)

        # Switch and repeat more times
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_back()
        nxt_values = nxt.get_values()[1,:].copy()
        nxt.replace_row(1,curr_values)

        curr = nxt
        curr_values = nxt_values
        nxt = self.get_left()
        nxt_values = nxt.get_values()[1,:].copy()
        nxt.replace_row(1,curr_values)

        # Don't need next values
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_face()
        nxt.replace_row(1,curr_values)

    def rotate_bottom_row_right(self):

        # Get current side and next with respect to rotation
        curr = self.get_face()
        nxt = self.get_right()

        # Get values for each
        curr_values = curr.get_values()[2,:].copy()
        nxt_values = nxt.get_values()[2,:].copy()

        # Replace with values for current
        nxt.replace_row(2,curr_values)

        # Switch and repeat more times
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_back()
        nxt_values = nxt.get_values()[2,:].copy()
        nxt.replace_row(2,curr_values)

        curr = nxt
        curr_values = nxt_values
        nxt = self.get_left()
        nxt_values = nxt.get_values()[2,:].copy()
        nxt.replace_row(2,curr_values)

        # Don't need next values
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_face()
        nxt.replace_row(2,curr_values)

    def rotate_top_row_left(self):

        # Get current side and next with respect to rotation
        curr = self.get_face()
        nxt = self.get_left()

        # Get values for each
        curr_values = curr.get_values()[0,:].copy()
        nxt_values = nxt.get_values()[0,:].copy()

        # Replace with values for current
        nxt.replace_row(0,curr_values)

        # Switch and repeat more times
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_back()
        nxt_values = nxt.get_values()[0,:].copy()
        nxt.replace_row(0,curr_values)

        curr = nxt
        curr_values = nxt_values
        nxt = self.get_right()
        nxt_values = nxt.get_values()[0,:].copy()
        nxt.replace_row(0,curr_values)

        # Don't need next values
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_face()
        nxt.replace_row(0,curr_values)

    def rotate_mid_row_left(self):

        # Get current side and next with respect to rotation
        curr = self.get_face()
        nxt = self.get_left()

        # Get values for each
        curr_values = curr.get_values()[1,:].copy()
        nxt_values = nxt.get_values()[1,:].copy()

        # Replace with values for current
        nxt.replace_row(1,curr_values)

        # Switch and repeat more times
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_back()
        nxt_values = nxt.get_values()[1,:].copy()
        nxt.replace_row(1,curr_values)

        curr = nxt
        curr_values = nxt_values
        nxt = self.get_right()
        nxt_values = nxt.get_values()[1,:].copy()
        nxt.replace_row(1,curr_values)

        # Don't need next values
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_face()
        nxt.replace_row(1,curr_values)

    def rotate_bottom_row_left(self):

        # Get current side and next with respect to rotation
        curr = self.get_face()
        nxt = self.get_left()

        # Get values for each
        curr_values = curr.get_values()[2,:].copy()
        nxt_values = nxt.get_values()[2,:].copy()

        # Replace with values for current
        nxt.replace_row(2,curr_values)

        # Switch and repeat more times
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_back()
        nxt_values = nxt.get_values()[2,:].copy()
        nxt.replace_row(2,curr_values)

        curr = nxt
        curr_values = nxt_values
        nxt = self.get_right()
        nxt_values = nxt.get_values()[2,:].copy()
        nxt.replace_row(2,curr_values)

        # Don't need next values
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_face()
        nxt.replace_row(2,curr_values)

    def rotate_left_col_up(self):

        # Get current side and next with respect to rotation
        curr = self.get_face()
        nxt = self.get_top()

        # Get values for each
        curr_values = curr.get_values()[:,0].copy()
        nxt_values = nxt.get_values()[:,0].copy()

        # Replace with values for current
        nxt.replace_col(0,curr_values)

        # Switch and repeat more times
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_back()
        nxt_values = nxt.get_values()[:,0].copy()
        nxt.replace_col(0,curr_values)

        curr = nxt
        curr_values = nxt_values
        nxt = self.get_bottom()
        nxt_values = nxt.get_values()[:,0].copy()
        nxt.replace_col(0,curr_values)

        # Don't need next values
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_face()
        nxt.replace_col(0,curr_values)

    def rotate_mid_col_up(self):

        # Get current side and next with respect to rotation
        curr = self.get_face()
        nxt = self.get_top()

        # Get values for each
        curr_values = curr.get_values()[:,1].copy()
        nxt_values = nxt.get_values()[:,1].copy()

        # Replace with values for current
        nxt.replace_col(1,curr_values)

        # Switch and repeat more times
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_back()
        nxt_values = nxt.get_values()[:,1].copy()
        nxt.replace_col(1,curr_values)

        curr = nxt
        curr_values = nxt_values
        nxt = self.get_bottom()
        nxt_values = nxt.get_values()[:,1].copy()
        nxt.replace_col(1,curr_values)

        # Don't need next values
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_face()
        nxt.replace_col(1,curr_values)

    def rotate_right_col_up(self):

        # Get current side and next with respect to rotation
        curr = self.get_face()
        nxt = self.get_top()

        # Get values for each
        curr_values = curr.get_values()[:,2].copy()
        nxt_values = nxt.get_values()[:,2].copy()

        # Replace with values for current
        nxt.replace_col(2,curr_values)

        # Switch and repeat more times
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_back()
        nxt_values = nxt.get_values()[:,2].copy()
        nxt.replace_col(2,curr_values)

        curr = nxt
        curr_values = nxt_values
        nxt = self.get_bottom()
        nxt_values = nxt.get_values()[:,2].copy()
        nxt.replace_col(2,curr_values)

        # Don't need next values
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_face()
        nxt.replace_col(2,curr_values)

    def rotate_left_col_down(self):

        # Get current side and next with respect to rotation
        curr = self.get_face()
        nxt = self.get_bottom()

        # Get values for each
        curr_values = curr.get_values()[:,0].copy()
        nxt_values = nxt.get_values()[:,0].copy()

        # Replace with values for current
        nxt.replace_col(0,curr_values)

        # Switch and repeat more times
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_back()
        nxt_values = nxt.get_values()[:,0].copy()
        nxt.replace_col(0,curr_values)

        curr = nxt
        curr_values = nxt_values
        nxt = self.get_top()
        nxt_values = nxt.get_values()[:,0].copy()
        nxt.replace_col(0,curr_values)

        # Don't need next values
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_face()
        nxt.replace_col(0,curr_values)

    def rotate_mid_col_down(self):

        # Get current side and next with respect to rotation
        curr = self.get_face()
        nxt = self.get_bottom()

        # Get values for each
        curr_values = curr.get_values()[:,1].copy()
        nxt_values = nxt.get_values()[:,1].copy()

        # Replace with values for current
        nxt.replace_col(1,curr_values)

        # Switch and repeat more times
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_back()
        nxt_values = nxt.get_values()[:,1].copy()
        nxt.replace_col(1,curr_values)

        curr = nxt
        curr_values = nxt_values
        nxt = self.get_top()
        nxt_values = nxt.get_values()[:,1].copy()
        nxt.replace_col(1,curr_values)

        # Don't need next values
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_face()
        nxt.replace_col(1,curr_values)

    def rotate_right_col_down(self):

        # Get current side and next with respect to rotation
        curr = self.get_face()
        nxt = self.get_bottom()

        # Get values for each
        curr_values = curr.get_values()[:,2].copy()
        nxt_values = nxt.get_values()[:,2].copy()

        # Replace with values for current
        nxt.replace_col(2,curr_values)

        # Switch and repeat more times
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_back()
        nxt_values = nxt.get_values()[:,2].copy()
        nxt.replace_col(2,curr_values)

        curr = nxt
        curr_values = nxt_values
        nxt = self.get_top()
        nxt_values = nxt.get_values()[:,2].copy()
        nxt.replace_col(2,curr_values)

        # Don't need next values
        curr = nxt
        curr_values = nxt_values
        nxt = self.get_face()
        nxt.replace_col(2,curr_values)
