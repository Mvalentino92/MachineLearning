# Will import everything
from RubiksEnvironment import *
import matplotlib.pyplot as plt

# Create the environment
env = Environment()

# Layers for the neural network
input_ = env.observation_space_size
hidden1 = 64
hidden2 = 24
output_ = env.action_space_size

# Building the model
class Model(nn.Module):
    def __init__(self):
        super(Model,self).__init__()
        self.input_ = nn.Linear(input_,hidden1)
        self.hidden1 = nn.Linear(hidden1,hidden2)
        self.hidden2 = nn.Linear(hidden2,output_)

    def forward(self,x):
        x = F.leaky_relu(self.input_(x))
        x = F.leaky_relu(self.hidden1(x))
        x = self.hidden2(x)
        return x

model = Model()

# Set up optimizer 
optimizer = torch.optim.Adam(model.parameters())

# Set loss function
loss_fn = nn.MSELoss()

# Set up episilon greedy strategy (break continuous task up into virtual termination
epsilon = 1
epochs = 5000
discount = 0.99
delta = 0.999
clips = 10
scores = []

for epoch in range(epochs):

    # Set up the environment, and begin
    state = env.reset()
    state = torch.from_numpy(state).float()
    done = False
    max_iter = 256

    # Begin while not solved, or virtual termination (max_iters)
    while not done and max_iter > 0:

        # Get vector from neural network representing action values for all actions
        # (want gradient)
        action_values = model(state)

        # Use epsilon greedy strategy to pick an action
        if np.random.rand() < epsilon:
            action = env.sample()
        else:
            action = torch.argmax(action_values)

        # Take a step with this action, and get observables
        state_prime,reward,done = env.step(action)
        state_prime = torch.from_numpy(state_prime).float()

        # Grab action value of selected action (prediction)
        y_hat = action_values[action]

        # Grab the discounted max action value of next state plus reward (target)
        # Don't want gradient
        with torch.no_grad():
            y = reward + discount*torch.max(model(state_prime)).detach()

        # Compute the loss
        loss = loss_fn(y_hat,y)

        # Zero out gradient
        optimizer.zero_grad()

        # Backprop
        loss.backward()

        # Step
        optimizer.step()

        # Set state as state_prime
        state = state_prime

        # Print the loss decrement max_iter
        max_iter -= 1

    if epsilon > 0.1:
        epsilon *= delta
    scores.append(env.cube.total_correct()) 

plt.plot(np.arange(len(scores)),np.array(scores))
plt.show()
