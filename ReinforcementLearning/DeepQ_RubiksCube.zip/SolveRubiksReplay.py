# Will import everything
from RubiksEnvironment import *
import matplotlib.pyplot as plt
from collections import deque
import random

# Create the environment
env = Environment()

# Layers for the neural network
input_ = env.observation_space_size
hidden1 = 576
hidden2 = 144
output_ = env.action_space_size

# Building the model
class Model(nn.Module):
    def __init__(self):
        super(Model,self).__init__()
        self.input_ = nn.Linear(input_,hidden1)
        self.hidden1 = nn.Linear(hidden1,hidden2)
        self.hidden2 = nn.Linear(hidden2,output_)

    def forward(self,x):
        x = F.leaky_relu(self.input_(x))
        x = F.leaky_relu(self.hidden1(x))
        x = self.hidden2(x)
        return x

model = Model()

# Set up optimizer 
lr = 0.00095
optimizer = torch.optim.Adam(model.parameters(),lr=lr)

# Set loss function
loss_fn = nn.MSELoss()

# Set up episilon greedy strategy (break continuous task up into virtual termination
epsilon = 1
epochs = 1000
discount = 0.99
delta = 0.1**(2/epochs)
clips = 10
scores = []
deque_len = 500
batch_size = 100
transitions = deque(maxlen=deque_len)
max_score = 0
best_board = None

for epoch in range(epochs):
    print(epoch)

    # Set up the environment, and begin
    state = env.reset()
    done = False
    max_iter = 100

    # Track max score per epoch
    epoch_score = 0
    epoch_board = None

    # Begin while not solved, or virtual termination (max_iters)
    while not done and max_iter > 0:

        # Get vector from neural network representing action values for all actions
        # No gradient (using batches of experience replay
        with torch.no_grad():
            action_values = model(torch.from_numpy(state).float())

        # Use epsilon greedy strategy to pick an action
        if np.random.rand() < epsilon:
            action = env.sample()
        else:
            action = torch.argmax(action_values)

        # Take a step with this action, and get observables
        state_prime,reward,done = env.step(action)

        # Add this state,action,state_prime, and reward tuple to transition deque
        transitions.append((state,action,state_prime,reward))

        # If we have enough in transition deque, run this batch
        if len(transitions) > batch_size:

            # Grab the batch
            batch = random.sample(transitions,batch_size)

            # Get all the parts from deque
            states = torch.Tensor([s for (s,a,sp,r) in batch])
            state_primes = torch.Tensor([sp for (s,a,sp,r) in batch])
            actions = [a for (s,a,sp,r) in batch]
            rewards = torch.Tensor([r for (s,a,sp,r) in batch])

            # Feed all states into the model (want gradients), and flatten
            action_values = model(states).view(-1)

            # Scale up actions by number to get index for flattened states
            actions = [i*output_ + actions[i] for i in range(len(actions))]

            # Grab all the action_values (predictions) for all the selected actions of the current states
            predictions = action_values[actions]

            # Compute the action values for prime states
            with torch.no_grad():
                action_values_prime = model(state_primes)

            # Grab the max values for each state prime
            targets = rewards + torch.max(action_values_prime,dim=1)[0]*discount

            # Compute the loss, zero grads, backprop, and step
            loss = loss_fn(predictions,targets)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        # Set state as state_prime
        state = state_prime

        # Print the loss decrement max_iter
        max_iter -= 1

        # Print best so far
        score = env.cube.total_correct()
        if score > epoch_score:
            epoch_score = score
            epoch_board = env.cube.get_cube()
    
    # Decrease epsilon
    if epsilon > 0.1:
        epsilon *= delta

    # Check if epoch_score is better
    if epoch_score > max_score:
        max_score = epoch_score
        best_board = epoch_board


    # Store epoch score
    scores.append(epoch_score) 

print(max_score)
print(best_board)
plt.scatter(np.arange(len(scores)),np.array(scores))
plt.show()
