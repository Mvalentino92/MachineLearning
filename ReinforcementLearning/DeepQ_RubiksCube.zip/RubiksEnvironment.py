# Will import numpy torch, ect
from RubiksCube import *

# Create the environemnt class, uses the Cube class.
class Environment:

    # Some general things
    def __init__(self):
        self.cube = None #wait for initialize
        self.action_space_size = 12
        self.observation_space_size = 54*6

    # The sample function
    def sample(self):
        return np.random.randint(self.action_space_size)

    # The reset function
    def reset(self):
        self.cube = Cube()
        self.cube.shuffle()
        return self.get_state()

    # Return the state in general
    def get_state(self):
        flat = np.concatenate((self.cube.get_face().get_values().flatten(),self.cube.get_back().get_values().flatten(),
                               self.cube.get_right().get_values().flatten(),self.cube.get_left().get_values().flatten(),
                               self.cube.get_top().get_values().flatten(),self.cube.get_bottom().get_values().flatten()))
        retval = np.array([])
        for i in flat:
            onehot = np.zeros(6)
            onehot[i] = 1
            retval = np.append(retval,onehot)

        return retval


    # Render the board (just prints)
    def render(self):
        self.cube.print_cube()

    # The step function
    def step(self,action):

        # Perform action
        self.cube.rotations[action]()

        # Get new observations (state)
        state = self.get_state()

        # Get reward
        reward = self.cube.total_correct()

        # Check if done
        done = self.cube.is_solved()

        # Return all
        return state,reward,done
